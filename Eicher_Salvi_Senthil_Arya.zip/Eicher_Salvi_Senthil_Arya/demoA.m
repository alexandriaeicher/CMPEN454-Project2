function [] = demoA()
    load 'Subject4-Session3-Take4_mocapJoints.mat' mocapJoints
    main(mocapJoints);
end