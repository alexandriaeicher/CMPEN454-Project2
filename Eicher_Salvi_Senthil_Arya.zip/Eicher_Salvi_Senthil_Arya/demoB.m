function error = demoB(jointData)
    error = main(jointData);
end